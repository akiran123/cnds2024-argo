export default {
  breaks: true
};
