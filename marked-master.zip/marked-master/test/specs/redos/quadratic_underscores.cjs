module.exports = {
  markdown: `${'_'.repeat(101)} a`,
  html: `<p>${'_'.repeat(101)} a</p>`
};
