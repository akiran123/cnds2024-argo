module.exports = {
  markdown: `# #${' '.repeat(50000)}a`,
  html: '<h1># a</h1>'
};
