---
gfm: true
---
| a | b | 
|---|---| 
| 1 | 2 | 
 
there should be a single space at the end of every line above
