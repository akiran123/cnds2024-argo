_**foo**_ **bar**

_**foo**_ **bar** _**foo**_

*__foo__* __bar__

*__foo__* __bar__ *__foo__*
