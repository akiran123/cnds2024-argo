`someone@example.com`

``*test`*