> not heading 1
==

> not heading 2
--

> heading 1
> ==

> heading 2
> --

> not heading 1
==
> not heading 2 with br  
--
